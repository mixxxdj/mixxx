var searchData=
[
  ['dualfilelogger_4',['DualFileLogger',['../classstefanfrings_1_1DualFileLogger.html#a8368cfe85bbc2e56f9d1cd0593c7c925',1,'stefanfrings::DualFileLogger::DualFileLogger()'],['../classstefanfrings_1_1DualFileLogger.html',1,'stefanfrings::DualFileLogger']]],
  ['dualfilelogger_2ecpp_5',['dualfilelogger.cpp',['../dualfilelogger_8cpp.html',1,'']]],
  ['dualfilelogger_2eh_6',['dualfilelogger.h',['../dualfilelogger_8h.html',1,'']]]
];
