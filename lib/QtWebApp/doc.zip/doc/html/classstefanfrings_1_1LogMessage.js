var classstefanfrings_1_1LogMessage =
[
    [ "LogMessage", "classstefanfrings_1_1LogMessage.html#aaad830e947d03f40e2fe0fb9f7e0851c", null ],
    [ "getType", "classstefanfrings_1_1LogMessage.html#a6e0563caa0e118de2b9664b08ee6c856", null ],
    [ "toString", "classstefanfrings_1_1LogMessage.html#a0afc95ed8eb8b5cc611b5b9436f65053", null ]
];