/*************************** testalib.cpp **********************************
* Author:        Agner Fog
* Date created:  2007-06-14
* Last modified: 2008-12-14
* Project:       asmlib.zip
* Source URL:    www.agner.org/optimize
*
* Description:
* Simple test of asmlib library
*
* Instructions:
* Compile for console mode and link with the appropriate version of asmlib
*
* Further documentation:
* The file asmlib-instructions.pdf contains further documentation and 
* instructions.
*
* Copyright 2007-2008 by Agner Fog. 
* GNU General Public License http://www.gnu.org/licenses/gpl.html
*****************************************************************************/

#include <stdio.h>
#include <string.h>
#include <memory.h>
#include <stdlib.h>
#include "asmlib.h"

void Failure(const char * text) {
   // Report if test failure
   printf("\nTest failed: %s\n", text);
   exit(1);
}

int main () {

   // test InstructionSet()
   printf("InstructionSet  = %i\n",   InstructionSet());

   // test cpuid_abcd
   int abcd[4]; char s[16];
   cpuid_abcd(abcd, 0);
   *(int*)(s+0) = abcd[1];             // ebx
   *(int*)(s+4) = abcd[3];             // edx
   *(int*)(s+8) = abcd[2];             // ecx
   s[12] = 0;                          // terminate string
   printf("Vendor string = %s \n", s);

   // test ProcessorName()
   printf("ProcessorName   = %s\n",   ProcessorName());
   
   // test ReadTSC()
   ReadTSC();
   int tsc = (int)ReadTSC();
   tsc = (int)ReadTSC() - tsc;
   printf("\nReadTSC takes %i clocks\n\n", tsc);  
   
   // test Round();
   double d;
   for (d = -2; d < 2; d += 0.5) {
      printf("Round %f = %i = %i\n", d, Round(d), Round(float(d)));
   }

   // Test memory and string functions
   int i, n;
   const int strsize = 256;
   char string1[strsize], string2[strsize];
   const char * teststring = "abcdefghijklmnopqrstuvwxyz ABCDEFGHIJKLMNOPQRSTUVWXYZ 1234567890 []{}";

   // Initialize strings
   A_memset(string1, 0, strsize);
   A_memset(string2, 0, strsize);

   // Test A_strcpy, A_strcat, A_strlen
   A_strcpy(string1, teststring);
   n = strsize/(int)A_strlen(teststring);
   for (i = 0; i < n-1; i++) {
      A_strcat(string1, teststring);
   }
   if (A_strlen(string1) != n * A_strlen(teststring)) Failure("A_strcpy, A_strcat, A_strlen");

   // Test stricmp_az
   A_memcpy(string2, string1, strsize);
   string2[4] ^= 0x20;  string2[30] ^= 0x20; // Change case
   if (stricmp_az(string1, string2) != 0)  Failure("stricmp_az");
   string2[8] += 2;  // Make strings different
   if (stricmp_az(string1, string2) >= 0)  Failure("stricmp_az");
   string2[7] -= 2;  // Make strings different
   if (stricmp_az(string1, string2) <= 0)  Failure("stricmp_az");

   // Test A_memmove with overlapping source and destination
   A_memmove(string2, string1, strsize);
   A_memmove(string1+3, string1+8, 12);
   memmove  (string2+3, string2+8, 12);

   A_memmove(string1+30, string1+41, 100);
   memmove  (string2+30, string2+41, 100);

   A_memmove(string1+32, string1+48, 77);
   memmove  (string2+32, string2+48, 77);

   A_memmove(string1+168, string1+100, 80);
   memmove  (string2+168, string2+100, 80);
   if (stricmp_az(string1, string2) != 0)  Failure("A_memmove");

   printf("\nTests passed OK\n");

   return 0;
}
